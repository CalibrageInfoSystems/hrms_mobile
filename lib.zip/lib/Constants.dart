class Constants {

  static const String IS_LOGIN = "login_verification";
  static const String USER_ID = "userID";
  static const String WELCOME = "welcome";
}
